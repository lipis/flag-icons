from flask import Module


mod = Module(__name__, 'foo', subdomain='foo')
